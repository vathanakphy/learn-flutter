import 'package:basic/QuizApp/model/question.dart';
import 'package:basic/QuizApp/model/submission.dart';

class QuizRepostiry {
  List<Submission> submissions = [];
  List<Question> questions = [];
}
