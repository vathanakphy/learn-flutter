import 'dart:ui';

class AppColors {
  static final Color primary = Color(0xff5E9FCD);
}

